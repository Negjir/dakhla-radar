MADAR Minerals - Kediet ej Jill (Zouerat)
CRS: WGS84 geographic (EPSG:4326). Source: ESA Copernicus Sentinel-2 L2A.
targets.geojson / targets.kml : ranked targets T1..T10 (points = weighted centre, polygons = anomalous patch),
                                plus the known reference site(s) used only for the blind test.
madar_score_20m.tif           : MADAR prospectivity score (float32, 0 = masked: vegetation, water, shadow, cloud).
indices_z_40m.tif             : robust z-scores x100 (int16) of the band-ratio indices, one band each:
                                clay, ferric, ferrous, ree
Model: iron. Targets = top 1.0% of the score, grouped, ranked by size x intensity.
Limits: MADAR narrows the search area; it does not prove a deposit. Field sampling and drilling decide.
